import sys
import os
import pytest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from app.main import app
from app.models import url_store

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_health_check(client):
    response = client.get('/')
    assert response.status_code == 200
    data = response.get_json()
    assert data['status'] == 'healthy'
    assert data['service'] == 'URL Shortener API'

def test_shorten_valid_url(client):
    response = client.post('/api/shorten', json={'url': 'https://example.com'})
    assert response.status_code == 200
    data = response.get_json()
    assert "short_code" in data
    assert "short_url" in data

def test_shorten_invalid_url(client):
    response = client.post('/api/shorten', json={'url': 'invalid-url'})
    assert response.status_code == 400
    data = response.get_json()
    assert "error" in data

def test_redirect_and_click_increment(client):
    # Shorten a valid URL
    shorten_resp = client.post('/api/shorten', json={'url': 'https://clicktest.com'})
    short_code = shorten_resp.get_json()['short_code']

    # Simulate a redirect
    redirect_resp = client.get(f'/{short_code}', follow_redirects=False)
    assert redirect_resp.status_code == 302
    assert 'https://clicktest.com' in redirect_resp.headers['Location']

    # Check click count in stats
    stats_resp = client.get(f'/api/stats/{short_code}')
    data = stats_resp.get_json()
    assert data['clicks'] == 1

def test_redirect_invalid_code(client):
    response = client.get('/invalid123')
    assert response.status_code == 404
    assert "error" in response.get_json()

def test_stats_invalid_code(client):
    response = client.get('/api/stats/fake123')
    assert response.status_code == 404
    assert "error" in response.get_json()

def test_stats_response_format(client):
    response = client.post('/api/shorten', json={'url': 'https://statcheck.com'})
    short_code = response.get_json()['short_code']

    stats_response = client.get(f'/api/stats/{short_code}')
    data = stats_response.get_json()

    assert "url" in data
    assert "clicks" in data
    assert "created_at" in data
