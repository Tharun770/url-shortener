# NOTES.md

## 🤖 AI Tool Usage Disclosure

In accordance with the assignment’s AI usage policy, the following outlines how AI assistance was utilized during the development of this project.

### Tools Used
- **ChatGPT (by OpenAI)**

### Purpose of Use
- Clarifying assignment requirements and scope.
- Designing a clean and modular architecture for the Flask application.
- Drafting boilerplate code for routing, utility functions, and test cases.
- Troubleshooting Python and Flask-related errors during development.
- Generating supporting documentation such as `.gitignore`, `README.md`, and `NOTES.md`.

### AI-Generated Code Review
- AI-generated code was used selectively and reviewed thoroughly.
- Logic for URL validation, short code generation, and error handling was adapted and modified for clarity, efficiency, and alignment with the project’s goals.
- All implementation decisions and final code structures were manually verified and tested.
- No code was used blindly without understanding its functionality and impact.

---

## 🧩 Implementation Overview

- The project uses a modular structure: `main.py` handles routes, `models.py` stores in-memory data, and `utils.py` provides reusable helper functions.
- The API is built using Flask and adheres to RESTful principles.
- Short codes are generated using secure 6-character alphanumeric strings.
- Flask’s built-in testing client and `pytest` were used to validate API behavior through automated tests.
- The entire service operates using in-memory storage without external dependencies, as per the assignment’s constraints.

---

## ✅ Technical Requirements Compliance

| Requirement                                      | Status  | Description                                                                 |
|--------------------------------------------------|---------|-----------------------------------------------------------------------------|
| URL validation                                   | ✅ Done | Ensures input URLs are valid before shortening                              |
| 6-character alphanumeric short codes             | ✅ Done | Uses random letters and digits to generate secure, unique codes             |
| Concurrent request handling                      | ✅ Done | In-memory structure safely supports simultaneous access in single-threaded use |
| Basic error handling                             | ✅ Done | Handles invalid inputs and unknown routes gracefully                        |
| Minimum 5 test cases                             | ✅ Done | Implemented 7 test cases to cover all critical scenarios                    |

---

## 🧪 Test Suite Coverage

| Test Case | Description                                                        |
|-----------|--------------------------------------------------------------------|
| ✅        | Health check endpoint (`GET /`)                                    |
| ✅        | URL shortening functionality (`POST /api/shorten`)                 |
| ✅        | Redirection via short code (`GET /<short_code>`)                   |
| ✅        | Analytics data retrieval (`GET /api/stats/<short_code>`)           |
| ✅        | Invalid URL returns `400 Bad Request`                              |
| ✅        | Invalid short code returns `404 Not Found` (redirect)              |
| ✅        | Invalid short code returns `404 Not Found` (analytics)             |

---

## 📦 Submission Checklist

1. ✅ Complete implementation of a functional URL shortening service
2. ✅ All required and edge test cases pass successfully (`pytest`)
3. ✅ This `NOTES.md` file documenting AI usage and project implementation

