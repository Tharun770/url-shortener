# TODO: Implement your data models here
# Consider what data structures you'll need for:
# - Storing URL mappings
# - Tracking click counts
# - Managing URL metadata
from datetime import datetime

# Dictionary to store URL mappings
# Format:
# {
#   "short_code": {
#       "url": "https://example.com",
#       "clicks": 0,
#       "created_at": datetime.now()
#   }
# }
url_store = {}

def save_url_mapping(short_code, original_url):
    url_store[short_code] = {
        "url": original_url,
        "clicks": 0,
        "created_at": datetime.now()
    }

def get_url_mapping(short_code):
    return url_store.get(short_code)

def increment_click_count(short_code):
    if short_code in url_store:
        url_store[short_code]["clicks"] += 1

def get_all_mappings():
    return url_store
