# TODO: Implement utility functions here
# Consider functions for:
# - Generating short codes
# - Validating URLs
# - Any other helper functions you need
import random
import string
import re
from urllib.parse import urlparse

def generate_short_code(length=6):
    chars = string.ascii_letters + string.digits
    return ''.join(random.choices(chars, k=length))

def is_valid_url(url):
    # Validate using urlparse
    parsed = urlparse(url)
    return all([parsed.scheme, parsed.netloc])
