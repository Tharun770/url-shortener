# IMPLEMENTATION.md

## 📌 Project Overview

This project is a simple URL Shortener API built using **Flask**. It allows users to shorten long URLs, redirect using short codes, and view analytics (click count, creation time, and original URL). Data is stored in-memory, making it lightweight and fast.

---

## 🛠️ Setup & Installation Instructions

Follow these steps to set up and run the project locally:

### 1. Clone or Download the Repository

```bash
git clone <your-repo-url>
cd url-shortener
Or if downloaded manually, just extract and open the url-shortener folder.

2. Create and Activate a Virtual Environment
Windows:
bash
Copy
Edit
python -m venv venv
venv\\Scripts\\activate
macOS/Linux:
bash
Copy
Edit
python3 -m venv venv
source venv/bin/activate
3. Install Dependencies
Make sure you're inside the virtual environment, then install required packages:

bash
Copy
Edit
pip install -r requirements.txt
Dependencies:

Flask==2.3.2

Werkzeug==2.3.6

pytest==7.4.0

4. Run the Flask Application
bash
Copy
Edit
python -m flask --app app.main run
The API will be available at: http://localhost:5000

🚀 API Endpoints
1. POST /api/shorten
Shortens a given URL.

Request:

json
Copy
Edit
{
  "url": "https://example.com/very/long/path"
}
Response:

json
Copy
Edit
{
  "short_code": "abc123",
  "short_url": "http://localhost:5000/abc123"
}
2. GET /<short_code>
Redirects to the original URL.

Example:
http://localhost:5000/abc123

3. GET /api/stats/<short_code>
Returns analytics data.

Response:

json
Copy
Edit
{
  "url": "https://example.com/very/long/path",
  "clicks": 3,
  "created_at": "2024-01-01T10:00:00"
}
🧪 Run Tests
Run all tests using:

bash
Copy
Edit
pytest
You should see all tests passing:

Copy
Edit
7 passed in 0.31s
📁 Project Structure
bash
Copy
Edit
url-shortener/
├── app/
│   ├── __init__.py
│   ├── main.py         # API routes
│   ├── models.py       # In-memory data storage
│   └── utils.py        # URL validation and short code generator
├── tests/
│   └── test_basic.py   # Functional tests
├── requirements.txt    # Python dependencies
├── .gitignore          # Files to exclude from version control
├── README.md           # Assignment instructions
├── NOTES.md            # AI usage disclosure
🧠 Design Decisions
Thread Safety: Used Python dictionaries safely under Flask's single-threaded model.

Code Organization: Separation of routing logic, models, and utilities for better maintainability.

Error Handling: Added custom error handlers for 400 and 404 cases.

Testing: Used Flask’s test client and pytest for comprehensive test coverage.

✅ Completion Checklist
 Core features implemented

 All technical requirements met

 Minimum 5 tests written and passing

 Submission-ready structure and documentation